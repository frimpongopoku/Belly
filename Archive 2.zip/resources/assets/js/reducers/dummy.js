export var initialState = [
		{ id: 23, owner: 'Frimpong', owner_id: 6, course: 'Computer Science', created_at:'3 hours ago' ,type:'text' ,title: 'Killing this 1',body: 'As your app grows, you can catch a lot of bugs with typechecking. For some applications, you can use JavaScript extensions like Flow or TypeScript to typecheck your whole application. But even if you don’t '}
		,{ id: 21, owner: 'Agyingo',owner_id: 6, course: 'Computer Science', created_at:'3 hours ago' ,type:'text', title: 'Killing this 2',body: 'Adisco boys As your app grows, you can catch a lot of bugs with typechecking. For some applications, you can use JavaScript extensions like Flow or TypeScript to typecheck your whole application. But even if you don’t '}
		,{ id: 56, owner: 'Gundi', owner_id: 6, course: 'Economics', created_at:'3 hours ago', type:'text' ,title: 'Killing this bingo',body: 'Agiss girls As your app grows, you can catch a lot of bugs with typechecking. For some applications, you can use JavaScript extensions like Flow or TypeScript to typecheck your whole application. But even if you don’t '}


	];


	// $(document).ready(function(){

	// 	setTimeout(function(){
	// 		$('.Tahiru').fadeIn(400);
	// 	},3000)//after 3 seconds
	// })

	// <div class='Tahiru' style='display:none'> 1 

	// </div>