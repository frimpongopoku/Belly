<?php $__env->startSection('title'); ?>
  QB | <?php echo e($found->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="padding:0; margin:0; margin-top:80px;width:100%">
    <div id='paper-view'></div>
    <div class="container phone-m-less">
      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 phone-m-less">
        <div class="thumbnail view-thumbnail clearfix" style="padding:20px;margin-bottom:5px;">
          <h2 style=" color:black; padding:7px;"><?php echo e($found->title); ?></h2>
          <div style="padding:20px;padding-top:0px; min-height:200px; max-height:515px;overflow-y:scroll; 
                border:solid 0px black; border-bottom-width:2px; margin-bottom:10px;">
            <p><?php echo e($found->body); ?><br>
              ----------------------<br>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime ducimus cupiditate soluta 
              saepe totam quis, suscipit est unde voluptatibus iusto nam magni excepturi officiis amet 
              quidem omnis alias. Provident, placeat.
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime ducimus cupiditate soluta 
              saepe totam quis, suscipit est unde voluptatibus iusto nam magni excepturi officiis amet 
              quidem omnis alias. Provident, placeat.
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime ducimus cupiditate soluta 
              saepe totam quis, suscipit est unde voluptatibus iusto nam magni excepturi officiis amet 
              quidem omnis alias. Provident, placeat.
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime ducimus cupiditate soluta 
              saepe totam quis, suscipit est unde voluptatibus iusto nam magni excepturi officiis amet 
              quidem omnis alias. Provident, placeat.
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime ducimus cupiditate soluta 
              saepe totam quis, suscipit est unde voluptatibus iusto nam magni excepturi officiis amet 
              quidem omnis alias. Provident, placeat.
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime ducimus cupiditate soluta 
              saepe totam quis, suscipit est unde voluptatibus iusto nam magni excepturi officiis amet 
              quidem omnis alias. Provident, placeat.
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime ducimus cupiditate soluta 
              saepe totam quis, suscipit est unde voluptatibus iusto nam magni excepturi officiis amet 
              quidem omnis alias. Provident, placeat.
            </p>
          </div>
          <?php if(Auth::user()->id == $found->user_id): ?>
            <button class="btn btn-danger btn-sm z-depth-1" id="delete"><i class="fa fa-trash"></i></button> 
          <?php endif; ?>
          <small class="label label-default rounded z-depth-1" style="padding:6px 10px; ">By <?php echo e('@'.$found->user->name); ?></small>
          <small class="label label-primary rounded z-depth-1" style="padding:6px 10px; "><?php echo e($found->course); ?></small>
          <small class='text text-default number-font'><?php echo e($found->created_at->diffForHumans()); ?></small>
          <div class = "pull-right"> 
            <?php if($user_has_liked): ?>
             <small class="cursor text text-danger"  id="liked"><i class='fa fa-thumbs-up'></i> <span class ='number-font' id="liked-span"><?php echo e(count($found->likes)); ?></span></small>
              <small class="cursor"style="display:none" id="like"><i class='fa fa-thumbs-up'></i> <span class ='number-font' id="like-span"><?php echo e(count($found->likes)); ?></span></small>
            <?php else: ?>
              <small class="cursor text text-danger" style="display:none" id="liked"><i class='fa fa-thumbs-up'></i> <span class ='number-font' id="liked-span"><?php echo e(count($found->likes)); ?></span></small>
              <small class="cursor" id="like"><i class='fa fa-thumbs-up'></i> <span class ='number-font' id="like-span"><?php echo e(count($found->likes)); ?></span></small>
            <?php endif; ?>
             <small class="cursor"data-toggle="modal" data-target="#comments-modal-box"><i class='fa fa-comment'></i> 
              <span class ='number-font comment-number'><?php echo e(count($found->comments)); ?></span></small>
          </div>
        </div>
          
        <div class="thumbnail zero-radius z-depth-1" style="padding:20px;margin-top:5px; height:100px;background:navajowhite"> 
            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-8">
                  <textarea class="form-control" placeholder="say something..." id="c-body"></textarea>
                  <small class='dark-text' style='display:none;padding:7px;margin:10px;color:green;'id='c-status'><i>commenting <span class='fa fa-spinner fa-spin'></span></i></small>
                  <input type="hidden" value ="<?php echo e($found->id); ?>" id="c-pieceID" />
                  <input type="hidden" value ="paper" id="c-type" />
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">
              
              <button class="btn btn-default user-badge-comment rounded v-c-b" id="c-btn" style="margin-top:10px;"><?php echo e('@'.Auth::user()->name); ?></button>
            </div>
          </form>
        </div>
        <div class="other-links" style=""> 
          <?php $__currentLoopData = $similar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piece): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12" style="padding-right:3px; padding-left:3px;"> 
                <div class="thumbnail z-depth-2 dark-text similar">
                  <p ><a style="color:crimson" href="/paper-view/MBZyU9WoGvD3M3OcszZ8skHvoPputaKIhq9uPmW6ZqImU8iwby1xOdirul1w2gGEgo2n2kZGRGjnVHaELEC1flWfpkOC1fM87KnTzlGW2Ah3BcoCOc9nlcB4cPNTcz8XK6SpztbVJk0zDwCpLparTW/<?php echo e($piece->id); ?>" target="_blank" > <?php echo e($piece->title); ?></a></p>
                  <p class="angel">By: @Agyingo</p>
                  <p class="angel"><?php echo e($piece->course); ?></p>
                </div>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class='modal fade' id="comments-modal-box" style="border-radius:15px;border:solid 2px orange;"> 
        <div class="modal-dialog modal-md">
          <div class="modal-content">
            <div class="modal-body" style="max-height:400px; overflow-y:scroll;  border-radius:10px;">
               <?php $__empty_1 = true; $__currentLoopData = $app_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div style="margin:6px">
                    <div class="comment-item-text rounded" id="lil-comment-<?php echo e($comment->id); ?>"> 
                      <small class='comment-item-title dark-text' style=""><b><?php echo e($comment->user->name); ?></b></small> 
                      <?php if(Auth::user()->id == $comment->user_id): ?>
                       <small><a href="#" class="lil-com" data-id="<?php echo e($comment->id); ?>"style="color:crimson">delete</a></small>
                      <?php endif; ?>
                       <small  class=''><p><?php echo e($comment->body); ?></p></small>
                     
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <center> 
                      <p style="margin:15px"> Be the first to comment <span class='fa fa-search'></span></p>
                  </center>
               <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
	<script> 
    var paperID = <?php echo e($found->id); ?>;
    var userID = <?php echo e(Auth::user()->id); ?>;
    $(document).ready(function(){
       var deleteComment=function(id){
        $.ajax({method:"get",url:'/delete-comment/'+id})
        .done(function(){
          $('#lil-comment-'+id).fadeOut(400);
        });
      }
      $('.lil-com').click(function(){
        deleteComment($(this).attr('data-id'));
      });
     
      var doDelete = function(){
        $.ajax({method:'get',url:"/me/delete-paper/"+paperID})
        .done(function(){
          window.close();
        });
      }

      $('#delete').click(function(){
        doDelete();
      })
      var backEndLike = function(){
        $.ajax({method:'get',url:'/me/like',data:{paper_piece_id:paperID,user_id:userID}});
      }
      $('#like').click(function(){
        doLike();
        backEndLike();
      });
       $('#liked').click(function(){
        unLike();
        backEndLike();
      });
      var doLike=function(){
        var num = Number(document.getElementById('like-span').innerHTML) +1;
        $('#like').fadeOut(function(){
           $('#liked').fadeIn();
        });
        document.getElementById('liked-span').innerHTML=num; 
        
      };
       var unLike=function(){
        var num = Number(document.getElementById('liked-span').innerHTML) -1;
         $('#liked').fadeOut(function(){
           $('#like').fadeIn();
        });
        document.getElementById('like-span').innerHTML=num; 
       
      };
      var doCommenting = function(){
        var body = $('#c-body').val(); 
        var type = $('#c-type').val(); 
        var id= $('#c-pieceID').val();
        if($.trim(body) !==""){
          $('#c-status').fadeIn();
          $.ajax({method:'get',url:"/me/save-comment",data:{body:body, type:type, pieceID:id}})
          .done(function(){
            setTimeout(function(){
              $('#c-status').fadeOut(function(){
                 $('#c-body').val("");
                 var theNumber = Number($('.comment-number').text())+1;
                 $('.comment-number').text(theNumber);
              });
            },500)
          });
        }
        else{
          alert("You have not written anything!");
        }
      }
      $('#c-btn').on('click',function(){
        doCommenting();
      });
    });
	</script>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.appnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>