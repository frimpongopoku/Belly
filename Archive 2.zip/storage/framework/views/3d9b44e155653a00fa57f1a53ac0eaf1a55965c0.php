<?php $__env->startSection('content'); ?>
<div class="container" style="padding:0; margin:0; width:100%">
    <div id='home' data-session-page=<?php echo e(Session::get('page_name')); ?>></div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
	<script> 
    var base_link =window.location.host;
    console.log("I am the host:: ", base_link)
	</script>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>