<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     
    <title>Question Belly</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('font/css/font-awesome.min.css')); ?> ">
    <link href='/css/welcome.css' />
</head>
<body>
    <div id="app" style="margin:0 !important; padding:0 !important">
               

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    

</body>
</html>
